(() => {
  // Public compatibility key for the default board; HTTPS, not this key, protects against sniffing.
  const DEFAULT_PUBLIC_KEY = '123456789123456';
  const $ = selector => document.querySelector(selector);
  const createForm = $('#chatCreateForm'), joinForm = $('#chatJoinForm'), form = $('#chatForm');
  const nameInput = $('#chatName'), textInput = $('#chatText'), sendButton = $('#chatSend');
  const status = $('#chatStatus'), list = $('#chatMessages'), roomInfo = $('#chatRoomInfo');
  const roomButtons = [$('#chatDefault'), $('#chatCreateToggle'), $('#chatJoinToggle')];
  const encoder = new TextEncoder(), decoder = new TextDecoder('utf-8', { fatal: true });
  let room = 'default', key = null, saltHex = '', version = 0, requestId = 0, busy = false, loaded = false;
  const decoded = new Map();

  const bytesToBase64 = bytes => btoa(String.fromCharCode(...bytes));
  const base64ToBytes = value => Uint8Array.from(atob(value), char => char.charCodeAt(0));
  const randomHex = count => Array.from(crypto.getRandomValues(new Uint8Array(count)), byte => byte.toString(16).padStart(2, '0')).join('');
  const url = id => id === 'default' ? 'cgi-bin/chat.sh' : `cgi-bin/chat.sh?room=${encodeURIComponent(id)}`;

  function secure() {
    if (!window.isSecureContext || !globalThis.crypto?.subtle) throw new Error('加密聊天需要 HTTPS（本机 localhost 也可使用）');
  }
  function showError(message) {
    status.textContent = message;
    let httpsLink;
    if (!window.isSecureContext && location.protocol === 'http:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
      httpsLink = document.createElement('a');
      httpsLink.href = `https://${location.host}${location.pathname}${location.search}${location.hash}`;
      httpsLink.textContent = '前往 HTTPS 页面';
      status.append(' · ', httpsLink);
    }
    if (loaded) return;
    const empty = document.createElement('div');
    empty.className = 'chat-placeholder';
    empty.textContent = message;
    if (httpsLink) {
      const link = httpsLink.cloneNode(true);
      empty.append(document.createElement('br'), link);
    }
    list.replaceChildren(empty);
  }
  async function getMessages(id) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(url(id), { cache: 'no-store', signal: controller.signal });
      if (response.status === 404) throw new Error(id === 'default' ? '聊天接口未找到，请检查 CGI 是否已部署' : '房间不存在，请检查房间 ID');
      if (!response.ok) throw new Error(`聊天接口返回 ${response.status}，请检查 CGI 执行权限与 chat 目录写权限`);
      let data;
      try { data = await response.json(); } catch (_) { throw new Error('聊天接口未返回 JSON，请检查 CGI 是否已启用'); }
      // Earlier single-room CGI responses did not include a check field.
      if (id === 'default' && data && data.check === undefined) data.check = '';
      if (!data || !/^[0-9a-f]{32}$/.test(data.salt) || !Array.isArray(data.messages) || typeof data.check !== 'string') throw new Error('聊天接口数据无效，请确认已部署新版 CGI');
      return data;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('读取留言超时，请检查网络及 CGI 服务');
      if (error instanceof TypeError) throw new Error('无法连接聊天接口，请检查网络及 CGI 配置');
      throw error;
    } finally { clearTimeout(timer); }
  }
  async function derive(secret, salt) {
    const material = await crypto.subtle.importKey('raw', encoder.encode(secret), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: Uint8Array.from(salt.match(/../g), hex => parseInt(hex, 16)), iterations: 210000, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function encrypt(value, cryptoKey) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cryptoKey, encoder.encode(JSON.stringify(value))));
    const envelope = new Uint8Array(iv.length + cipher.length);
    envelope.set(iv);
    envelope.set(cipher, iv.length);
    return bytesToBase64(envelope);
  }
  async function decrypt(envelope, cryptoKey) {
    const bytes = base64ToBytes(envelope);
    if (bytes.length < 29) throw new Error('密文无效');
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: bytes.slice(0, 12) }, cryptoKey, bytes.slice(12));
    return JSON.parse(decoder.decode(plain));
  }
  function senderHue(name) {
    let hash = 0;
    for (const char of name) hash = (Math.imul(hash, 31) + char.codePointAt(0)) >>> 0;
    return hash % 360;
  }
  function render(messages, invalid) {
    // On first load or room switch show the newest message; while reading older
    // messages, background refreshes must not pull the reader back to the bottom.
    const nearBottom = !loaded || list.scrollHeight - list.scrollTop - list.clientHeight < 60;
    loaded = true;
    list.replaceChildren();
    if (!messages.length) {
      const empty = document.createElement('div');
      empty.className = 'chat-placeholder';
      empty.textContent = invalid ? '无法解密留言（旧口令或损坏的消息）' : '还没有留言，来发第一条吧';
      list.append(empty);
    }
    for (const message of messages) {
      const item = document.createElement('article');
      item.className = 'chat-message';
      const hue = senderHue(message.name);
      item.style.setProperty('--bubble-bg', `hsl(${hue} 75% 96%)`);
      item.style.setProperty('--bubble-border', `hsl(${hue} 50% 84%)`);
      item.style.setProperty('--name-color', `hsl(${hue} 57% 35%)`);
      const head = document.createElement('div');
      head.className = 'chat-message-head';
      const author = document.createElement('strong');
      author.textContent = message.name;
      const time = document.createElement('time');
      time.textContent = new Date(message.time).toLocaleString();
      const body = document.createElement('div');
      body.className = 'chat-message-text';
      body.textContent = message.text;
      head.append(author, time);
      item.append(head, body);
      list.append(item);
    }
    if (nearBottom) list.scrollTop = list.scrollHeight;
    status.textContent = invalid ? `${invalid} 条留言无法解密（可能是旧口令发送的消息）` : room === 'default' ? '默认房间公开可读；请勿发送隐私信息' : '房间口令仅在当前页面使用，服务器只保存密文';
  }
  async function refresh() {
    if (!key) return;
    const currentRoom = room, currentKey = key, currentVersion = version, currentRequest = ++requestId;
    try {
      const data = await getMessages(currentRoom);
      if (data.salt !== saltHex) throw new Error('房间盐值已改变，请重新加入');
      let invalid = 0;
      const messages = [];
      for (const envelope of data.messages) {
        try {
          if (!decoded.has(envelope)) decoded.set(envelope, await decrypt(envelope, currentKey));
          const message = decoded.get(envelope);
          if (typeof message.name !== 'string' || typeof message.text !== 'string' || typeof message.time !== 'number') throw new Error('留言无效');
          messages.push(message);
        } catch (_) { invalid++; }
      }
      if (currentVersion === version && currentRequest === requestId) render(messages, invalid);
    } catch (error) {
      if (currentVersion === version && currentRequest === requestId) showError(error.message || '读取聊天失败');
    }
  }
  function showPanel(panel) {
    createForm.hidden = panel !== 'create';
    joinForm.hidden = panel !== 'join';
    if (panel === 'create') $('#chatCreatePassphrase').focus();
    if (panel === 'join') $('#chatJoinRoom').focus();
  }
  $('#chatLatest').addEventListener('click', () => {
    list.scrollTo({ top: list.scrollHeight, behavior: 'smooth' });
  });
  $('#chatCompose').addEventListener('click', () => {
    if (textInput.disabled) {
      status.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    form.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    (nameInput.value.trim() ? textInput : nameInput).focus({ preventScroll: true });
  });
  function selectRoom(id) {
    room = id;
    key = null;
    saltHex = '';
    version++;
    requestId++;
    decoded.clear();
    textInput.value = '';
    loaded = false;
    nameInput.disabled = true;
    textInput.disabled = true;
    sendButton.disabled = true;
    status.textContent = '正在读取留言…';
    const pending = document.createElement('div');
    pending.className = 'chat-placeholder';
    pending.textContent = '正在读取留言…';
    list.replaceChildren(pending);
    $('#chatRoomTitle').textContent = id === 'default' ? '默认聊天 · 留言板' : '独立聊天房间';
    $('#chatRoomSubtitle').textContent = id === 'default' ? '公开留言板 · 自动进入' : `房间 ID：${id}`;
    roomInfo.hidden = id === 'default';
    roomInfo.textContent = id === 'default' ? '' : `房间 ID：${id} · 分享房间 ID 和口令给其他访客即可加入`;
    roomButtons[0].classList.toggle('active', id === 'default');
    showPanel('');
  }
  async function openRoom(id, secret, existingKey) {
    // The public room must become visible even if its CGI or HTTPS setup fails.
    if (id === 'default') selectRoom(id);
    secure();
    if (secret.length < 12) throw new Error('房间口令至少需要 12 个字符');
    const data = await getMessages(id);
    const roomKey = existingKey || await derive(secret, data.salt);
    if (data.check) {
      let check;
      try { check = await decrypt(data.check, roomKey); } catch (_) { throw new Error('房间口令错误'); }
      if (check.kind !== 'room-check' || check.room !== id) throw new Error('房间口令错误');
    } else if (id !== 'default') throw new Error('房间缺少口令校验信息');
    if (id !== 'default') selectRoom(id);
    key = roomKey;
    saltHex = data.salt;
    nameInput.disabled = false;
    textInput.disabled = false;
    sendButton.disabled = false;
    await refresh();
  }
  async function run(task) {
    if (busy) return;
    busy = true;
    roomButtons.forEach(button => { button.disabled = true; });
    try { await task(); } catch (error) { showError(error.message || '操作失败'); }
    finally { roomButtons.forEach(button => { button.disabled = false; }); busy = false; }
  }

  roomButtons[0].addEventListener('click', () => run(() => openRoom('default', DEFAULT_PUBLIC_KEY)));
  roomButtons[1].addEventListener('click', () => showPanel(createForm.hidden ? 'create' : ''));
  roomButtons[2].addEventListener('click', () => showPanel(joinForm.hidden ? 'join' : ''));
  createForm.addEventListener('submit', event => {
    event.preventDefault();
    run(async () => {
      secure();
      const secret = $('#chatCreatePassphrase').value;
      if (secret.length < 12) throw new Error('房间口令至少需要 12 个字符');
      const id = randomHex(16), salt = randomHex(16);
      const roomKey = await derive(secret, salt);
      const check = await encrypt({ kind: 'room-check', room: id }, roomKey);
      const response = await fetch(`${url(id)}&action=create&salt=${salt}`, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: check, cache: 'no-store' });
      if (!response.ok) throw new Error('创建房间失败，请重试');
      $('#chatCreatePassphrase').value = '';
      await openRoom(id, secret, roomKey);
    });
  });
  joinForm.addEventListener('submit', event => {
    event.preventDefault();
    run(async () => {
      const id = $('#chatJoinRoom').value.trim().toLowerCase();
      const secret = $('#chatJoinPassphrase').value;
      if (!/^[0-9a-f]{32}$/.test(id)) throw new Error('请输入正确的 32 位房间 ID');
      await openRoom(id, secret);
      $('#chatJoinPassphrase').value = '';
    });
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const name = nameInput.value.trim(), text = textInput.value.trim();
    if (!key || !name || !text || name.length > 32 || text.length > 1000 || sendButton.disabled) return;
    const currentRoom = room, currentKey = key, currentVersion = version;
    sendButton.disabled = true;
    try {
      const envelope = await encrypt({ name, text, time: Date.now() }, currentKey);
      const response = await fetch(url(currentRoom), { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: envelope, cache: 'no-store' });
      if (!response.ok) throw new Error('留言发送失败');
      if (currentVersion === version) {
        textInput.value = '';
        await refresh();
        list.scrollTop = list.scrollHeight;
      }
    } catch (error) {
      if (currentVersion === version) status.textContent = error.message || '留言发送失败';
    } finally { if (currentVersion === version) sendButton.disabled = false; }
  });
  run(() => openRoom('default', DEFAULT_PUBLIC_KEY));
  setInterval(refresh, 10000);
})();