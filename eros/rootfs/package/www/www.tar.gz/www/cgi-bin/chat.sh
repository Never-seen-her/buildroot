#!/bin/sh
# Only encrypted, base64-encoded AES-GCM envelopes are accepted and stored here.
BASE=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd) || exit 1
CHAT="$BASE/chat"
LOCK="$CHAT/.lock"
umask 077
reply_error() {
  printf 'Status: %s\r\nContent-Type: application/json\r\nCache-Control: no-store\r\n\r\n{"error":"%s"}\n' "$1" "$2"
  exit 0
}
case "${REQUEST_METHOD:-GET}" in GET|POST) ;; *) reply_error '405 Method Not Allowed' 'method not allowed';; esac
q() { printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | sed -n "s/^$1=//p" | head -n 1; }
room=$(q room)
action=$(q action)
[ -n "$room" ] || room=default
case "$room" in
  default) ROOM="$CHAT" ;;
  *[!0-9a-f]*|'') reply_error '400 Bad Request' 'invalid room';;
  *) [ "${#room}" -eq 32 ] || reply_error '400 Bad Request' 'invalid room'
     ROOM="$CHAT/rooms/$room" ;;
esac
case "$action" in
  '') ;;
  create) [ "${REQUEST_METHOD:-GET}" = POST ] && [ "$room" != default ] || reply_error '400 Bad Request' 'invalid action' ;;
  *) reply_error '400 Bad Request' 'invalid action' ;;
esac
payload=
if [ "${REQUEST_METHOD:-GET}" = POST ]; then
  len=${CONTENT_LENGTH:-0}
  case "$len" in ''|*[!0-9]*) reply_error '400 Bad Request' 'invalid length';; esac
  [ "$len" -ge 40 ] && [ "$len" -le 8192 ] || reply_error '413 Content Too Large' 'invalid length'
  payload=$(dd bs="$len" count=1 iflag=fullblock 2>/dev/null) || reply_error '400 Bad Request' 'invalid body'
  [ "${#payload}" -eq "$len" ] || reply_error '400 Bad Request' 'incomplete body'
  case "$payload" in *[!A-Za-z0-9+/=]*|'') reply_error '400 Bad Request' 'invalid envelope';; esac
  printf '%s\n' "$payload" | LC_ALL=C grep -Eq '^[A-Za-z0-9+/]+={0,2}$' || reply_error '400 Bad Request' 'invalid envelope'
  [ $((${#payload} % 4)) -eq 0 ] || reply_error '400 Bad Request' 'invalid envelope'
fi
mkdir -p "$CHAT" || reply_error '500 Internal Server Error' 'storage unavailable'
i=0
until mkdir "$LOCK" 2>/dev/null; do
  i=$((i + 1))
  [ "$i" -lt 5 ] || reply_error '503 Service Unavailable' 'storage busy'
  sleep 1
done
trap 'rmdir "$LOCK" 2>/dev/null' 0
trap 'exit 1' 1 2 3 15
if [ "$action" = create ]; then
  salt=$(q salt)
  case "$salt" in *[!0-9a-f]*|'') reply_error '400 Bad Request' 'invalid salt';; esac
  [ "${#salt}" -eq 32 ] || reply_error '400 Bad Request' 'invalid salt'
  mkdir -p "$CHAT/rooms" || reply_error '500 Internal Server Error' 'storage unavailable'
  mkdir -m 700 "$ROOM" 2>/dev/null || reply_error '409 Conflict' 'room already exists'
  if ! { printf '%s\n' "$salt" > "$ROOM/salt" && printf '%s\n' "$payload" > "$ROOM/check"; }; then
    rm -f "$ROOM/salt" "$ROOM/check"
    rmdir "$ROOM" 2>/dev/null
    reply_error '500 Internal Server Error' 'storage unavailable'
  fi
  printf 'Status: 201 Created\r\nContent-Type: application/json\r\nCache-Control: no-store\r\n\r\n{"ok":true}\n'
  exit 0
fi
if [ "$room" = default ] && [ ! -s "$ROOM/salt" ]; then
  salt=$(od -An -N16 -tx1 /dev/urandom | tr -d ' \n')
  [ "${#salt}" -eq 32 ] || reply_error '500 Internal Server Error' 'random unavailable'
  printf '%s\n' "$salt" > "$ROOM/salt" || reply_error '500 Internal Server Error' 'storage unavailable'
fi
[ -s "$ROOM/salt" ] || reply_error '404 Not Found' 'room not found'
if [ "${REQUEST_METHOD:-GET}" = POST ]; then
  printf '%s\n' "$payload" >> "$ROOM/messages.log" || reply_error '500 Internal Server Error' 'storage unavailable'
  printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n{"ok":true}\n'
else
  salt=$(cat "$ROOM/salt")
  check=
  [ ! -f "$ROOM/check" ] || check=$(cat "$ROOM/check")
  printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n{"salt":"%s","check":"%s","messages":[' "$salt" "$check"
  first=1
  if [ -f "$ROOM/messages.log" ]; then
    tail -n 100 "$ROOM/messages.log" | while IFS= read -r line; do
      case "$line" in *[!A-Za-z0-9+/=]*|'') continue;; esac
      [ "$first" -eq 1 ] || printf ','
      first=0
      printf '"%s"' "$line"
    done
  fi
  printf ']}\n'
fi