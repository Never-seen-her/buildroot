#!/bin/sh
BASE=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd); LOGDIR="$BASE/logs"; LOGFILE="$LOGDIR/access.log"
mkdir -p "$LOGDIR"; umask 077
clean(){ printf '%s' "$1" | tr '\t\r\n' '   ' | cut -c1-500; }
client_ip=${HTTP_X_FORWARDED_FOR:-${HTTP_X_REAL_IP:-${REMOTE_ADDR:-unknown}}}; client_ip=$(printf '%s' "$client_ip" | sed 's/,.*//')
printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$(clean "$client_ip")" "$(clean "${HTTP_USER_AGENT:-unknown}")" "$(clean "${REQUEST_METHOD:-GET}")" "$(clean "${1:-visit}")" "$(clean "${2:-}")" >> "$LOGFILE"
