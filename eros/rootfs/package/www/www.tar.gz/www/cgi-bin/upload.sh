#!/bin/sh
BASE=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd); MEDIA="$BASE/media"; LIMIT=1073741824
q(){ printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | sed -n "s/^$1=//p" | head -n 1; }
url_decode(){ printf '%s' "$1" | sed 's/+/ /g;s/%/\\x/g' | xargs -0 printf '%b' 2>/dev/null; }
name=$(url_decode "$(q name)"); name=$(basename "$name"); name=$(printf '%s' "$name" | tr -cd 'A-Za-z0-9._() -'); [ -n "$name" ] || name=upload.bin
file="$MEDIA/$name"; action=$(q action); size=0; [ -f "$file" ] && size=$(wc -c < "$file" | tr -d ' ')
if [ "$action" = status ]; then printf 'Content-Type: application/json\r\n\r\n{"size":%s}\n' "${size:-0}"; exit 0; fi
offset=$(q offset); total=$(q total); offset=${offset:-0}; total=${total:-0}; current=${size:-0}
[ "$current" -eq "$offset" ] || { printf 'Status: 409 Conflict\r\nContent-Type: application/json\r\n\r\n{"error":"offset mismatch","size":%s}\n' "$current"; exit 0; }
mkdir -p "$MEDIA" "$BASE/tmp"; len=${CONTENT_LENGTH:-0}; tmp="$BASE/tmp/upload.$$"; : > "$tmp"
received=0
if [ "$len" -gt 0 ]; then
  blocks=$(( (len + 131071) / 131072 ))
  dd if=/dev/stdin of="$tmp" bs=131072 count="$blocks" iflag=fullblock 2>/dev/null
  received=$(wc -c < "$tmp" | tr -d ' ')
fi
[ "$offset" -eq 0 ] && : > "$file"; cat "$tmp" >> "$file"; rm -f "$tmp"
newsize=$(wc -c < "$file" | tr -d ' '); is_video=false
case "$name" in *.mp4|*.webm|*.ogg|*.mov|*.m4v|*.avi|*.mkv|*.mpeg|*.mpg) is_video=true;; esac
if [ "$is_video" = true ]; then used=0; for path in "$MEDIA"/*; do case "$path" in *.mp4|*.webm|*.ogg|*.mov|*.m4v|*.avi|*.mkv|*.mpeg|*.mpg) [ -f "$path" ] && used=$((used + $(wc -c < "$path" | tr -d ' '))) ;; esac; done; while [ "$used" -gt "$LIMIT" ]; do old=$(find "$MEDIA" -maxdepth 1 -type f \( -name '*.mp4' -o -name '*.webm' -o -name '*.ogg' -o -name '*.mov' -o -name '*.m4v' -o -name '*.avi' -o -name '*.mkv' -o -name '*.mpeg' -o -name '*.mpg' \) -printf '%T@ %p\n' | sort -n | head -n 1 | cut -d' ' -f2-); [ -n "$old" ] || break; [ "$old" = "$file" ] && break; rm -f -- "$old"; used=0; for path in "$MEDIA"/*; do case "$path" in *.mp4|*.webm|*.ogg|*.mov|*.m4v|*.avi|*.mkv|*.mpeg|*.mpg) [ -f "$path" ] && used=$((used + $(wc -c < "$path" | tr -d ' '))) ;; esac; done; done; fi
if [ "$offset" -eq 0 ]; then "$BASE/cgi-bin/log_event.sh" upload "开始上传 $name" >/dev/null 2>&1; fi
complete=false; [ "$total" -gt 0 ] && [ "$newsize" -ge "$total" ] && complete=true
if [ "$complete" = true ]; then "$BASE/cgi-bin/log_event.sh" upload "上传完成 $name ($newsize bytes)" >/dev/null 2>&1; fi
printf 'Content-Type: application/json\r\n\r\n{"size":%s,"complete":%s}\n' "$newsize" "$complete"
