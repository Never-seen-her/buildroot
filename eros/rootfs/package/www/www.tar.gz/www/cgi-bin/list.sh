#!/bin/sh
BASE=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd); MEDIA="$BASE/media"
"$BASE/cgi-bin/log_event.sh" visit "扫描媒体列表" >/dev/null 2>&1
printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n'
json_escape(){ printf '%s' "$1" | sed 's/\\/\\\\/g;s/"/\\"/g'; }
video_bytes=0; first=1; printf '{"items":['
for path in "$MEDIA"/*; do
  [ -f "$path" ] || continue
  name=${path##*/}; size=$(wc -c < "$path" | tr -d ' '); type=image
  case "$name" in *.mp4|*.webm|*.ogg|*.mov|*.m4v|*.avi|*.mkv|*.mpeg|*.mpg) type=video; video_bytes=$((video_bytes + size));; esac
  [ "$first" = 1 ] || printf ','; first=0
  printf '{"name":"'; json_escape "$name"; printf '","url":"media/'; json_escape "$name"; printf '","type":"%s","bytes":%s}' "$type" "$size"
done
printf '],"videoBytes":%s}\n' "$video_bytes"
