#!/bin/sh
BASE=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd); MEDIA="$BASE/media"
q(){ printf '%s' "${QUERY_STRING:-}" | tr '&' '\n' | sed -n "s/^$1=//p" | head -n 1; }
url_decode(){ printf '%s' "$1" | sed 's/+/ /g;s/%/\\x/g' | xargs -0 printf '%b' 2>/dev/null; }
name=$(url_decode "$(q name)"); name=$(basename "$name"); name=$(printf '%s' "$name" | tr -cd 'A-Za-z0-9._() -'); file="$MEDIA/$name"
printf 'Content-Type: application/json\r\n\r\n'
if [ -n "$name" ] && [ -f "$file" ]; then rm -f -- "$file"; "$BASE/cgi-bin/log_event.sh" delete "删除 $name" >/dev/null 2>&1; printf '{"ok":true}\n'; else printf '{"ok":false,"error":"file not found"}\n'; fi
