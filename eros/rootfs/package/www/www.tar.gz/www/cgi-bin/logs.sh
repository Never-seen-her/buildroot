#!/bin/sh
BASE=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd); FILE="$BASE/logs/access.log"
printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n{"items":['
first=1
if [ -f "$FILE" ]; then tail -n 100 "$FILE" | while IFS="	" read -r time ip agent method action detail; do
  [ "$first" = 1 ] || printf ','; first=0
  esc(){ printf '%s' "$1" | sed 's/\\/\\\\/g;s/"/\\"/g;s/\r//g;s/\n//g'; }
  printf '{"time":"';esc "$time";printf '","ip":"';esc "$ip";printf '","agent":"';esc "$agent";printf '","method":"';esc "$method";printf '","action":"';esc "$action";printf '","detail":"';esc "$detail";printf '"}'
done; fi
printf ']}\n'
