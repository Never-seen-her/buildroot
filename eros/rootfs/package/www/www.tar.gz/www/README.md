# Video Vault CGI Edition

这是一个纯静态 HTML/CSS/JavaScript + POSIX Shell CGI 的媒体网页，不需要 Python、Node 或数据库。

## 部署到 `/tmp/www`

```sh
mkdir -p /tmp/www
unzip video-vault-cgi.zip -d /tmp/www
cd /tmp/www
chmod 755 cgi-bin/*.sh
chmod 775 media tmp logs chat
```

视频和图片统一存放在 `/tmp/www/media`。默认房间的密文和随机盐存放在与 `media` 并列的 `/tmp/www/chat`（首次访问时生成）；独立房间存放在 `/tmp/www/chat/rooms/<房间 ID>/`，CGI 进程必须对 `chat` 及其子目录有写权限。网页通过文件扩展名识别视频或图片，视频空间上限为 1 GiB，图片不计入视频配额。

将 Web 服务器的站点根目录指向 `/tmp/www`，并开启 `cgi-bin` 执行权限。Apache 示例：

```apache
DocumentRoot /tmp/www
<Directory /tmp/www>
    Options Indexes FollowSymLinks ExecCGI
    AllowOverride All
    AddHandler cgi-script .sh
    Require all granted
</Directory>
```

生产部署必须启用 HTTPS，禁止使用 HTTP 提供页面或 CGI：否则抓包者可以篡改页面脚本，绕过浏览器端加密。Apache 示例配置需启用 `mod_authz_core`，并确认 `/chat/.htaccess` 被加载以禁止直接访问聊天目录。Nginx 需要把 `/cgi-bin/` 转发到支持 CGI 的 fcgiwrap，并配置 `location ^~ /chat/ { deny all; }`；不要对外暴露该目录。静态 `/media/` 直接指向媒体目录。浏览器不能直接双击 HTML 文件；本机开发可用 localhost。

## 功能

- 页面进入后自动扫描 `media/`。
- 支持视频播放、图片预览、搜索和类型筛选。
- 上传按 256 KB 分片，显示速度；暂停后按服务器实际文件大小续传。
- 视频目录超过 1 GiB 时，自动删除最早修改的视频。
- 媒体列表置顶，留言板聊天框与上传媒体并排显示；移动端自动上下排列。
- 打开页面自动进入默认聊天留言板，不需要输入口令或房间 ID；默认房间消息在浏览器加密后发送，服务器仍只存储密文。为兼容已有留言，默认房间使用随前端脚本公开的固定加密材料，**任何人都能获取该材料并解密默认留言，不能用于保密信息**；防止抓包读取的关键是正确配置 HTTPS，而不是公开的固定密钥。升级前若默认房间曾使用其他口令，其旧消息仍保留，但无法用当前默认密钥解密。
- 点击“创建聊天”并设置强口令（至少 12 个字符）即可创建独立房间，页面显示随机生成的 32 位房间 ID；把房间 ID 和口令分享给其他人，他们可点击“加入聊天”进入。房间口令不发送给服务器、不保存在浏览器本地存储；刷新页面会回到默认房间，需重新输入 ID 与口令。每个新房间具有独立的随机盐和密文口令校验信息，输入错误口令时会拒绝进入，服务器无法找回口令。
- 发送前使用 PBKDF2-SHA-256（210000 次迭代）派生 AES-256-GCM 密钥，昵称、内容及时间一并加密；读取时只下载密文并在浏览器中解密。默认房间记录追加到 `chat/messages.log`，独立房间记录追加到 `chat/rooms/<房间 ID>/messages.log`；页面只展示每个房间最近 100 条。聊天路径及访问日志仍可能泄露访问时间/IP，HTTPS 负责保护页面和传输元数据。

脚本使用 Linux 常见的 `sh`、`find`、`dd`、`awk`、`sed`、`sort`、`wc`、`rm`、`od`、`grep`，未使用 Python。请确认 CGI 进程用户对 `media/`、`tmp/`、`logs/` 和 `chat/` 有写权限，并确保新增的 `cgi-bin/chat.sh` 有执行权限。

## 留言一直无法加载时

- 页面提示“加密聊天需要 HTTPS”：请通过 HTTPS 访问网页（本机 `localhost` 可例外）。普通 HTTP 非安全上下文无法使用浏览器 Web Crypto API，不能在不降低安全性的前提下自动解密。
- 提示 CGI 未找到、返回错误码或未返回 JSON：确认 `cgi-bin/chat.sh` 已上传、具有执行权限且 Web 服务器已启用 CGI，同时确认 CGI 进程对 `chat/` 有写权限。媒体接口可用并不代表新的聊天 CGI 也已部署。
- 更新网页后仍出现旧提示：强制刷新浏览器，使新的聊天脚本生效。
- 若网站同时提供 HTTP 和 HTTPS，HTTP 页面上的昵称和发送按钮会保持禁用：请访问 HTTPS 地址。若 HTTPS 页面提示聊天接口 404，应将 `cgi-bin/chat.sh` 部署到 **HTTPS 站点实际使用的站点根目录**，并赋予执行权限；仅上传静态页面无法使聊天工作。发布后在浏览器打开站点的 `/cgi-bin/chat.sh`，应返回带 `salt`、`check`、`messages` 字段的 JSON，而不是 404 或脚本文本。
