(()=>{
  const grid=document.querySelector('#mediaGrid'), viewer=document.querySelector('#viewer'), content=document.querySelector('#viewerContent');
  if(!grid)return;
  const preview=card=>{
    if(card.dataset.preview||!card.querySelector('.play'))return;
    card.dataset.preview='loading'; const src=card.dataset.id, thumb=card.querySelector('.thumb');
    const v=document.createElement('video'); v.src=src; v.preload='metadata'; v.muted=true; v.playsInline=true;
    v.addEventListener('loadedmetadata',()=>{try{v.currentTime=0}catch(e){}});
    v.addEventListener('seeked',()=>{try{const c=document.createElement('canvas'),w=v.videoWidth||320,h=v.videoHeight||180;c.width=w;c.height=h;c.getContext('2d').drawImage(v,0,0,w,h);const img=document.createElement('img');img.src=c.toDataURL('image/jpeg',.82);img.alt='视频预览';thumb.replaceChildren(img);card.dataset.preview='ready'}catch(e){card.dataset.preview='failed'}});
    v.addEventListener('error',()=>{card.dataset.preview='failed'}); v.load();
  };
  const scan=()=>grid.querySelectorAll('.media-card').forEach(preview); new MutationObserver(scan).observe(grid,{childList:true}); scan();
  document.querySelector('#closeViewer')?.addEventListener('click',()=>{const v=content.querySelector('video');if(v){v.pause();v.removeAttribute('src');v.load()}content.replaceChildren()},true);
})();
